package es.uma.informatica.jpa.demo;

import es.uma.informatica.jpa.demo.ValoracionActividad;
import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: ValoracionProfesor
 *
 */
@Entity

public class ValoracionProfesor extends ValoracionActividad implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	private Profesor profesor;
	
	
	public Profesor getProfesor() {
		return profesor;
	}


	public void setProfesor(Profesor profesor) {
		this.profesor = profesor;
	}


	public ValoracionProfesor() {
		super();
	}
   
}
