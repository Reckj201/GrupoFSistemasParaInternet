package es.uma.informatica.sii.ejb;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.core.UriBuilder;

import es.uma.informatica.sii.jsf.autenticacion.modelo.Actividades;
import es.uma.informatica.sii.jsf.autenticacion.modelo.Alumno;
import es.uma.informatica.sii.jsf.autenticacion.modelo.ONG;
import es.uma.informatica.sii.jsf.autenticacion.modelo.Profesor;
import es.uma.informatica.sii.jsf.autenticacion.modelo.Usuario;
import es.uma.informatica.sii.jsf.autenticacion.modelo.ValoracionActividad;
import es.uma.informatica.sii.jsf.autenticacion.modelo.ValoracionProfesor;

@Stateless
public class BaseDeDatos implements BasedeDatosLocal{
	private static final int TAM_CADENA_VALIDACION = 20;
    private static final Logger LOGGER = Logger.getLogger(BaseDeDatos.class.getCanonicalName());

	@PersistenceContext(unitName = "practica-jsf")
	private EntityManager em;
	
	@Override
	public List<ONG> todoONG() {
		// TODO Auto-generated method stub
		Query query = em.createQuery("Select a from ONG a where a.Borrada like :perrito").setParameter("perrito", false);
		
		return query.getResultList();
	}

	@Override
	public void aniadirONG(ONG o) {
		// TODO Auto-generated method stub
		Profesor aux = em.find(Profesor.class, o.getOngs_profesor().getDNI());
		List<ONG> aux2=aux.getOng();
		aux2.add(o);
		em.persist(o);
	}

	@Override
	public void eliminarONG(ONG o) {
		// TODO Auto-generated method stub
		em.remove(em.merge(o));
	}

	@Override
	public List<Actividades> todoActividades() {
		// TODO Auto-generated method stub
		return em.createNamedQuery("Actividades.todos", Actividades.class).getResultList();
	}

	@Override
	public void aniadirActividad(Actividades a) {
		// TODO Auto-generated method stub
		
		em.persist(a);
	}

	@Override
	public void eliminarActividad(Actividades a) {
		// TODO Auto-generated method stub
		em.remove(em.merge(a));
	}

	@Override
	public List<ValoracionActividad> todoValoracionActividad() {
		// TODO Auto-generated method stub
		return em.createNamedQuery("ValoracionActividad.todos", ValoracionActividad.class).getResultList();
	}

	@Override
	public void aniadirValoracionActividad(ValoracionActividad va) {
		// TODO Auto-generated method stub
		em.persist(va);
		Actividades aux = em.find(Actividades.class, va.getFk_actividad().getCodigo_Act());
		aux.getListaValoraciones().add(va);
	}

	@Override
	public void eliminarValoracionActividad(ValoracionActividad va) {
		// TODO Auto-generated method stub
		em.remove(em.merge(va));
	}

	@Override
	public List<Alumno> todoAlumnos() {
		// TODO Auto-generated method stub
		return em.createNamedQuery("Alumno.todos", Alumno.class).getResultList();
	}

	 @Override
	    public String aniadirAlumno(Alumno u, UriBuilder uriBuilder) {	       
		 	u.setCadenaValidacion(generarCadenaAleatoria());
	        em.persist(u);

	        URI uriValidacion = uriBuilder.build(u.getDNI(), u.getCadenaValidacion());

	        LOGGER.info(uriValidacion.toString());
	        return "validarCuenta.xhtml?dni="+u.getDNI()+"&codigoValidacion="+u.getCadenaValidacion();
	    }

	    private String generarCadenaAleatoria() {
	        Random rnd = new Random(System.currentTimeMillis());
	        StringBuilder sb = new StringBuilder();

	        for (int i = 0; i < TAM_CADENA_VALIDACION; i++) {
	            int v = rnd.nextInt(62);
	            if (v < 26) {
	                sb.append((char) ('a' + v));
	            } else if (v < 52) {
	                sb.append((char) ('A' + v - 26));
	            } else {
	                sb.append((char) ('0' + v - 52));
	            }
	        }

	        return sb.toString();

	    }

	@Override
	public void eliminarAlumno(Alumno a) {
		// TODO Auto-generated method stub
		em.remove(em.merge(a));
	}

	@Override
	public List<Profesor> todoProfesor() {
		// TODO Auto-generated method stub
		return em.createNamedQuery("Profesor.todos", Profesor.class).getResultList();
	}

	@Override
	public void aniadirProfesor(Profesor p) {
		// TODO Auto-generated method stub
		em.persist(p);
		em.flush();
	}

	@Override
	public void eliminarProfesor(Profesor p) {
		// TODO Auto-generated method stub
		em.remove(em.merge(p));
	}

	@Override
	public List<ValoracionProfesor> todoValoracionProfesor() {
		// TODO Auto-generated method stub
		return em.createNamedQuery("ValoracionProfesor.todos", ValoracionProfesor.class).getResultList();
	}

	@Override
	public void aniadirValoracionProfesor(ValoracionProfesor vp) {
		// TODO Auto-generated method stub
		em.persist(vp);
	}

	@Override
	public void eliminarValoracionProfesor(ValoracionProfesor vp) {
		// TODO Auto-generated method stub
		em.remove(em.merge(vp));
	}

	@Override
	public List<Usuario> todoUsuario() {
		// TODO Auto-generated method stub
		return em.createNamedQuery("Usuario.todos", Usuario.class).getResultList();
	}
	
	@Override
	public void validarCuenta(String dni, String validacion)   {
        Usuario u = em.find(Usuario.class, dni);
       if(u.getCadenaValidacion()!=null){
    	   if (u.getCadenaValidacion().equals(validacion)) {
               u.setCadenaValidacion(null);
           }
       }
    }
	
	@Override
	public void aniadirUsuario(Usuario u) {
		// TODO Auto-generated method stub
		em.persist(u);
	}

	@Override
	public void eliminarUsuario(Usuario u) {
		// TODO Auto-generated method stub
		em.remove(em.merge(u));
	}

	@Override
	public List<Actividades> todoActividadesfromONG(ONG o) {
		// TODO Auto-generated method stub
		Query query = em.createQuery("Select a from Actividades a where a.ong like :perrito").setParameter("perrito", o);
		return query.getResultList();
	}

	@Override
	public List<Actividades> todoActividadesfromUsuario(Usuario u) {
		// TODO Auto-generated method stub
		Query query = em.createQuery("Select a.estaEnActividad from Usuario a where a like :perrito").setParameter("perrito", u);
		return query.getResultList();
	}
	
	@Override
	public boolean UsuarioestaEnActividad(Usuario u,Actividades a) {
		// TODO Auto-generated method stub
		Usuario aux = em.find(Usuario.class, u.getDNI());
		return aux.getEstaEnActividad().contains(a);
	}

	@Override
	public List<ValoracionActividad> todoValoracionActividadfromActividad(Actividades a) {
		// TODO Auto-generated method stub
		Query query = em.createQuery("Select va from ValoracionActividad va where va.fk_actividad like :perrito").setParameter("perrito", a);
		return query.getResultList();
	}

	@Override
	public void inscribirseActividad(Actividades a, Usuario u) {
		// TODO Auto-generated method stub
		Usuario uaux = em.find(Usuario.class, u.getDNI());
		List<Actividades> uaux2 = uaux.getEstaEnActividad();
		uaux2.add(a);
		
		Actividades aux = em.find(Actividades.class, a.getCodigo_Act());
		List<Usuario> aux2 = aux.getParticipaUsuario();
		aux2.add(u);
	}

	@Override
	public List<Usuario> todoUsuarioFromActividad(Actividades a) {
		// TODO Auto-generated method stub
		Query query = em.createQuery("Select a.participaUsuario from Actividades a where a like :perrito").setParameter("perrito", a);
		return query.getResultList();
	}

	@Override
	public void actualizarUsuario(Usuario u) {
		// TODO Auto-generated method stub
		Usuario aux = em.find(Usuario.class, u.getDNI());
		aux.setNombre(u.getNombre());
		aux.setApellido1(u.getApellido1());
		aux.setApellido2(u.getApellido2());
		aux.setDireccion(u.getDireccion());
		aux.setPassword(u.getPassword());
	}

	@Override
	public String actualizarPlazasAct(Actividades a) {
		// TODO Auto-generated method stub
		Actividades aux = em.find(Actividades.class, a.getCodigo_Act());
		String b = Integer.toString(aux.getParticipaUsuario().size()) + "/" + Integer.toString(aux.getPlazas());
		return b;
	}
	
	@Override
	public Integer plazasOcupadasAct(Actividades a) {
		// TODO Auto-generated method stub
		Actividades aux = em.find(Actividades.class, a.getCodigo_Act());
		Integer b = aux.getParticipaUsuario().size();
		return b;
	}

	@Override
	public void eliminarUsuarioFromActividad(Usuario u, Actividades a) {
		// TODO Auto-generated method stub
		Usuario aux = em.find(Usuario.class, u.getDNI());
		aux.getEstaEnActividad().remove(a);
		
		Actividades aux2 = em.find(Actividades.class, a.getCodigo_Act());
		aux2.getParticipaUsuario().remove(u);
		
	}
	
	@Override
	public void eliminarValoracionFromActividad(ValoracionActividad va, Actividades a) {
		// TODO Auto-generated method stub
		
		Actividades aux2 = em.find(Actividades.class, a.getCodigo_Act());
		aux2.getListaValoraciones().remove(va);
		
	}

	@Override
	public boolean ActividadYaValorada(Actividades a, Usuario u) {
		// TODO Auto-generated method stub
		Usuario aux = em.find(Usuario.class, u.getDNI());
		
		Actividades aux2 = em.find(Actividades.class, a.getCodigo_Act());
		for (ValoracionActividad i : aux2.getListaValoraciones()) {
			if(i.getFk_user_va().equals(aux)) {
				return true;
			}
		}
		
		return false;
	}

	@Override
	public List<ONG> todoOngfromAdminActivas(Profesor p) {
		// TODO Auto-generated method stub
		
		Query query = em.createQuery("Select a from ONG a where a.ongs_profesor like :perrito AND a.Borrada like :perrito2").setParameter("perrito", p).setParameter("perrito2", false);
		return query.getResultList();
	}
	
	@Override
	public List<ONG> todoOngfromAdminBorradas(Profesor p) {
		// TODO Auto-generated method stub
		
		Query query = em.createQuery("Select a from ONG a where a.ongs_profesor like :perrito AND a.Borrada like :perrito2").setParameter("perrito", p).setParameter("perrito2", true);
		return query.getResultList();
	}

	@Override
	public void eliminarTodoONG(ONG o) {
		// TODO Auto-generated method stub
		ONG auxONG = em.find(ONG.class, o.getCodigo_ong());
		auxONG.setBorrada(true);
		
		
		/*Profesor auxP = em.find(Profesor.class, auxONG.getOngs_profesor().getDNI());
		auxP.getOng().remove(auxONG);
		
		
		for (Actividades i : auxONG.getActividades()) {
			List<Usuario> borrar1= new ArrayList<>();
			borrar1.addAll(i.getParticipaUsuario());
			
			
			
			for (Usuario j : borrar1) {
				
				eliminarUsuarioFromActividad(j, i);
				
			}
			
			List<ValoracionActividad> borrar2= new ArrayList<>();
			borrar2.addAll(i.getListaValoraciones());
			for (ValoracionActividad j : borrar2) {
				
				eliminarValoracionFromActividad(j,i);
				
				//em.remove(em.merge(j));
				
			}
			
			//em.remove(em.merge(i));
			
		}*/
		
		
	}

	@Override
	public void actualizarONG(ONG o) {
		// TODO Auto-generated method stub
		ONG aux = em.find(ONG.class, o.getCodigo_ong());
		aux.setNombre(o.getNombre());
		aux.setDescripcion(o.getDescripcion());
	}

	@Override
	public void actualizarActividad(Actividades o) {
		// TODO Auto-generated method stub
		Actividades aux = em.find(Actividades.class, o.getCodigo_Act());
		aux.setNombre(o.getNombre());
		aux.setDescripcion(o.getDescripcion());
		aux.setFecha_Fin(o.getFecha_Fin());
		aux.setFecha_Inicio(o.getFecha_Inicio());
		aux.setPlazas(o.getPlazas());
		aux.setTipo(o.getTipo());
	}

	
	
	/*
	public static void main(String args[]) {
		ONG o = new ONG();
		o.setCodigo_ong(123);
		o.setDescripcion("a");
		o.setNombre("CobrillaONG");
		o.setProfesor(new Profesor());
		
		
		aniadirONG(o);
	}
	*/
}
