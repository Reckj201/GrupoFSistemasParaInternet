package es.uma.informatica.sii.jsf.autenticacion.modelo;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;
import java.util.Date;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: ValoracionActividad
 *
 */
@NamedQuery (name = "ValoracionActividad.todos", query = "Select va from ValoracionActividad va" )
@Entity

public class ValoracionActividad implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column (nullable = false)
	private Integer Puntuacion;
	@Id@GeneratedValue
	private Integer codigo_valoracion;
	
	

	private String Contenido;
	private Date Fecha;
	
	@ManyToOne
	//@JoinColumn(name = "const_alumno", updatable = false, nullable = false)
	private Usuario fk_user_va;
	
	public Integer getCodigo_valoracion() {
		return codigo_valoracion;
	}
	public void setCodigo_valoracion(Integer codigo_valoracion) {
		this.codigo_valoracion = codigo_valoracion;
	}
	
	public Usuario getFk_user_va() {
		return fk_user_va;
	}
	public void setFk_user_va(Usuario fk_user_va) {
		this.fk_user_va = fk_user_va;
	}
	public Actividades getFk_actividad() {
		return fk_actividad;
	}
	public void setFk_actividad(Actividades fk_actividad) {
		this.fk_actividad = fk_actividad;
	}

	@ManyToOne
	private Actividades fk_actividad;
	

	public ValoracionActividad() {
		super();
	}   
	public Integer getPuntuacion() {
		return this.Puntuacion;
	}

	public void setPuntuacion(Integer Puntuacion) {
		this.Puntuacion = Puntuacion;
	}   
	public String getContenido() {
		return this.Contenido;
	}

	public void setContenido(String Contenido) {
		this.Contenido = Contenido;
	}   
	public Date getFecha() {
		return this.Fecha;
	}

	public void setFecha(Date Fecha) {
		this.Fecha = Fecha;
	}
   
}
