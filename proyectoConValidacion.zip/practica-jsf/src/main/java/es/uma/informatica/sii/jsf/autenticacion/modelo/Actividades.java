package es.uma.informatica.sii.jsf.autenticacion.modelo;

import java.io.Serializable;
import java.lang.Integer;
import java.lang.String;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Actividades
 *
 */
//@NamedQuery (name = "ActividadesFromONG.todos", query = "Select a from Actividades a where a.ong = login.currentONG" )
@NamedQuery (name = "Actividades.todos", query = "Select a from Actividades a" )
@Entity

public class Actividades implements Serializable {

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Codigo_Act == null) ? 0 : Codigo_Act.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Actividades other = (Actividades) obj;
		if (Codigo_Act == null) {
			if (other.Codigo_Act != null)
				return false;
		} else if (!Codigo_Act.equals(other.Codigo_Act))
			return false;
		return true;
	}
	private static final long serialVersionUID = 1L;
	@Id @GeneratedValue
	private Integer Codigo_Act;
	@Column (nullable = false)
	private Integer Plazas;
	private String Nombre;
	private String Descripcion;
	private Date Fecha_Inicio;
	@OneToMany (mappedBy = "fk_actividad")
	private List<ValoracionActividad> listaValoraciones;
	public List<ValoracionActividad> getListaValoraciones() {
		return listaValoraciones;
	}
	public void setListaValoraciones(List<ValoracionActividad> listaValoraciones) {
		this.listaValoraciones = listaValoraciones;
	}
	
	@Column
	private Boolean Borrada;
	
	public Boolean getBorrada() {
		return Borrada;
	}
	public void setBorrada(Boolean borrada) {
		Borrada = borrada;
	}
	private Date Fecha_Fin;
	private String Tipo;
	@JoinColumn (nullable = false)
	@ManyToOne
	private ONG ong;
	public ONG getOng() {
		return ong;
	}
	public void setOng(ONG ong) {
		this.ong = ong;
	}
	@ManyToMany(fetch = FetchType.EAGER , mappedBy = "estaEnActividad")
	private List<Usuario> participaUsuario;

	public List<Usuario> getParticipaUsuario() {
		return participaUsuario;
	}
	public void setParticipaUsuario(List<Usuario> participaUsuario) {
		this.participaUsuario = participaUsuario;
	}
	public Actividades() {
		super();
	}   
	public Integer getCodigo_Act() {
		return this.Codigo_Act;
	}

	public void setCodigo_Act(Integer Codigo_Act) {
		this.Codigo_Act = Codigo_Act;
	}   
	public Integer getPlazas() {
		return this.Plazas;
	}

	public void setPlazas(Integer Plazas) {
		this.Plazas = Plazas;
	}   
	public String getDescripcion() {
		return this.Descripcion;
	}

	public void setDescripcion(String Descripcion) {
		this.Descripcion = Descripcion;
	}   
	public Date getFecha_Inicio() {
		return this.Fecha_Inicio;
	}

	public void setFecha_Inicio(Date Fecha_Inicio) {
		this.Fecha_Inicio = Fecha_Inicio;
	}   
	public Date getFecha_Fin() {
		return this.Fecha_Fin;
	}

	public void setFecha_Fin(Date Fecha_Fin) {
		this.Fecha_Fin = Fecha_Fin;
	}   
	public String getTipo() {
		return this.Tipo;
	}

	public void setTipo(String Tipo) {
		this.Tipo = Tipo;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
   
}
