package es.uma.informatica.sii.ejb;

import es.uma.informatica.sii.jsf.autenticacion.Login;
import es.uma.informatica.sii.jsf.autenticacion.modelo.*;
import java.util.*;

import javax.ejb.Local;
import javax.ws.rs.core.UriBuilder;

@Local
public interface BasedeDatosLocal {
	List<ONG> todoONG();
	List<ONG> todoOngfromAdminActivas(Profesor p);
	List<ONG> todoOngfromAdminBorradas(Profesor p);
	void aniadirONG (ONG o);
	void eliminarONG (ONG o);
	void eliminarTodoONG(ONG o);
	void actualizarONG(ONG o);
	
	List<Actividades> todoActividades ();
	List<Actividades> todoActividadesfromONG (ONG o);
	List<Actividades> todoActividadesfromUsuario (Usuario a);
	void aniadirActividad (Actividades a);
	void eliminarActividad (Actividades a);
	void inscribirseActividad (Actividades a, Usuario u);
	String actualizarPlazasAct(Actividades a);
	Integer plazasOcupadasAct(Actividades a);
	void actualizarActividad(Actividades o);
	
	List<ValoracionActividad> todoValoracionActividad();
	List<ValoracionActividad> todoValoracionActividadfromActividad(Actividades a);
	void aniadirValoracionActividad (ValoracionActividad va);
	void eliminarValoracionActividad (ValoracionActividad va);
	void eliminarValoracionFromActividad(ValoracionActividad va, Actividades a);
	
	List<Alumno> todoAlumnos();
	String aniadirAlumno (Alumno a,UriBuilder uriBuilder);
	void eliminarAlumno (Alumno a);
	
	List<Profesor> todoProfesor();
	void aniadirProfesor (Profesor p);
	void eliminarProfesor (Profesor p);
	
	List<Usuario> todoUsuario();
	List<Usuario> todoUsuarioFromActividad(Actividades a);
	void aniadirUsuario (Usuario u);
	void actualizarUsuario (Usuario u);
	void eliminarUsuario (Usuario u);
	void eliminarUsuarioFromActividad(Usuario u, Actividades a);
	
	List<ValoracionProfesor> todoValoracionProfesor();
	void aniadirValoracionProfesor (ValoracionProfesor a);
	void eliminarValoracionProfesor (ValoracionProfesor a);
	
	public boolean UsuarioestaEnActividad(Usuario u,Actividades a);
	public boolean ActividadYaValorada(Actividades a,Usuario u);
	void validarCuenta(String dni, String validacion);
}
