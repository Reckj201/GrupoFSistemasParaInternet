/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uma.informatica.sii.jsf.autenticacion;



import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;


import es.uma.informatica.sii.ejb.*;
import es.uma.informatica.sii.jsf.autenticacion.modelo.*;

/**
 *
 * @author cobrilla
 */
@Named(value = "login")
@RequestScoped
public class Login {

	@Inject
	private BasedeDatosLocal bd;
	
	
    private static String usuario;
    private static String contrasenia;
    
    
    public static List<Alumno> alumnos = new ArrayList<Alumno>();
    public static List<Profesor> prof =new ArrayList<Profesor>();

    public static List<ONG> ong = new ArrayList<ONG>();
    public static Alumno currentuser;
    public static Profesor currentuser2;
    public static ONG currentONG;
    public static Actividades currentActividad;

    @Inject
    private ControlAutorizacion ctrl;

    /**
     * Creates a new instance of Login
     * @throws ParseException 
     */
    public Login() throws ParseException {
    	
    }
    
    
    public String getUsuario() {
        return usuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public  void setUsuario(String usuariol) {
        usuario = usuariol;
    }

    public void setContrasenia(String contrasenial) {
        contrasenia = contrasenial;
    }

    public String crearUser() {
		return "crearUser.xhtml";
    }
    
    public String getcurrentNombre() {
        return currentuser.getNombre();
    }
    public String getcurrentApellido1() {
        return currentuser.getApellido1();
    }
    public String getcurrentApellido2() {
        return currentuser.getApellido2();
    }
    public String getcurrentDNI() {
        return currentuser.getDNI();
    }
    public String getcurrentEmail() {
        return currentuser.getEmail();
    }
    public String getcurrentDireccion() {
        return currentuser.getDireccion();
    }
    public String getcurrentNum_expediente() {
        return Integer.toString(currentuser.getNum_expediente());
    }
    
    public String getcurrentNombre2() {
        return currentuser2.getNombre();
    }
    public String getcurrentApellido12() {
        return currentuser2.getApellido1();
    }
    public String getcurrentApellido22() {
        return currentuser2.getApellido2();
    }
    public String getcurrentDNI2() {
        return currentuser2.getDNI();
    }
    public String getcurrentEmail2() {
        return currentuser2.getEmail();
    }
    public String getcurrentDireccion2() {
        return currentuser2.getDireccion();
    }
    public String getcurrentNum_docente() {
        return Integer.toString(currentuser2.getNum_docente());
    }
    
    public String getcurrentONGNombre() {
        return currentONG.getNombre();
    }
    public String getcurrentONGDescripcion() {
        return currentONG.getDescripcion();
    }
    public String getcurrentONGProfesor() {
        return currentONG.getOngs_profesor().getNombre();
    }
    
    public String getcurrentActividadNombre() {
        return currentActividad.getNombre();
    }
    public String getcurrentActividadDescripcion() {
        return currentActividad.getDescripcion();
    }
    public String getcurrentActividadPlazas() {
    	return bd.actualizarPlazasAct(currentActividad);
    }
    
    public String getcurrentActividadFecha_Inicio() {
    	return currentActividad.getFecha_Inicio().toString();
    }
    public String getcurrentActividadFecha_Fin() {
    	return currentActividad.getFecha_Fin().toString();
    }
    
    public String getcurrentONGNombreActividad(String a) {
    	Integer n = Integer.parseInt(a);
    	return currentONG.getActividades().get(n).getNombre();
    }
    
    
    public String crearOng() {
    	
    	return "crearONG.xhtml";
    }
    
    public String crearActividad() {
    	FacesContext ctx = FacesContext.getCurrentInstance();
    	
    	if(currentONG.getBorrada()) {
    		ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Esta ONG esta borrada, no puedes añadir actividades", "Esta ONG esta borrada, no puedes añadir actividades"));
    		return "perfilONGprof.xhtml";
    	}
    	
    	return "crearActividad.xhtml";
    }
    
    public String verActividad(Actividades a) {
    	currentActividad = a;
    	return "perfilActividad.xhtml";
    }
    
    public String valorar() {
    	return "crearValoracionActividad.xhtml";
    }
    
    public List<ONG> getlistaOng(){
    	
    	
    	return bd.todoONG();
    }
    
    public String estaBorrada(ONG o) {
    	String res = "";
    	if(o!=null) {
    		if(o.getBorrada()) {
    			res = "true";
    		}else {
    			res = "false";
    		}
    		
    		return res;
    	}else {
    		return "false";
    	}
    }
    
    public List<Actividades> getlistaActAlumno(){
    	Usuario aux = new Usuario();
    	if(ctrl.getCurrentalumno()!=null) {
    		aux = ctrl.getCurrentalumno();
    	}else if(ctrl.getCurrentprofesor()!=null) {
    		aux = ctrl.getCurrentprofesor();
    	}
    	return bd.todoActividadesfromUsuario(aux);
    }
    
    public String anularInscripcion(Actividades a) {
    	
    	return "perfilAl.xhtml";
    }
    
    public String verOng(ONG o) {
    	currentONG=o;
    	return "perfilONG.xhtml";
    }
    
    public String verOngprof(ONG o) {
    	currentONG=o;
    	return "perfilONGprof.xhtml";
    }
    
    public List<Actividades> getcurrentONGActividades() {
    	return bd.todoActividadesfromONG(currentONG);
    }
    
    public List<ONG> getlistaONGAdminActivas(){
    	return bd.todoOngfromAdminActivas(ctrl.getCurrentprofesor());
    }
    
    public List<ONG> getlistaONGAdminBorradas(){
    	return bd.todoOngfromAdminBorradas(ctrl.getCurrentprofesor());
    }
    
    public String eliminarONG(ONG o) {
    	bd.eliminarTodoONG(o);
    	return "perfilProfesor.xhtml";
    }
    
    public List<ValoracionActividad> getcurrentVaFromActividad() {
    	return bd.todoValoracionActividadfromActividad(currentActividad);
    }
    
    public List<Usuario> getTodoUsuarioFromActividad() {
    	return bd.todoUsuarioFromActividad(currentActividad);
    }
    
    public String eliminarUser(Usuario u) {
    	bd.eliminarUsuarioFromActividad(u,currentActividad);
    	return "perfilActividad.xhtml";
    }
    
    public String eliminarUser(Actividades a) {
    	Usuario aux = new Usuario();
    	String destino="";
    	if(ctrl.getCurrentalumno()!=null) {
    		aux = ctrl.getCurrentalumno();
    		destino = "perfilAl.xhtml";
    	}else if(ctrl.getCurrentprofesor()!=null) {
    		aux = ctrl.getCurrentprofesor();
    		destino = "perfilProfesor.xhtml";
    	}
    	bd.eliminarUsuarioFromActividad(aux,a);
    	return destino;
    }
    
    public String inscribirse() {
    	Usuario aux=new Usuario();
    	if(ctrl.getCurrentalumno()!=null) {
    		aux=ctrl.getCurrentalumno();
    	}else if(ctrl.getCurrentprofesor()!=null) {
    		aux=ctrl.getCurrentprofesor();
    	}
    	String destino = "";
    	FacesContext ctx = FacesContext.getCurrentInstance();
    	if(bd.plazasOcupadasAct(currentActividad)==0) {
    		bd.inscribirseActividad(currentActividad, aux);
    		
    		destino = "perfilActividad.xhtml";
    	}else if(bd.plazasOcupadasAct(currentActividad) >= currentActividad.getPlazas()) {
    		ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "No hay espacio para ti", "No cabes bro"));
    		destino = "perfilActividad.xhtml";
    	}else if(bd.UsuarioestaEnActividad(aux, currentActividad)) {
    		ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ya estas en esta actividad", "No te apuntes dos veces bro"));
    		destino = "perfilActividad.xhtml";
    	}else {
    		bd.inscribirseActividad(currentActividad, aux);
    	}
    	
    	return destino;
    }
    
    
    public String autenticar() {
    	alumnos = bd.todoAlumnos();
    	prof = bd.todoProfesor();
		FacesContext ctx = FacesContext.getCurrentInstance();
		//Login a= new Login();
		
		
    	Alumno act=new Alumno();
    	String destino = "login.xhtml";
    
    	act.setDNI(usuario);
    	act.setPassword(contrasenia);
    	int encontrado = alumnos.indexOf(act);
    	if(encontrado!=-1) {
    		if(!alumnos.get(encontrado).getPassword().equals(contrasenia)) {
                ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Contraseña errónea", "Contraseña errónea"));
    		}else {
    			currentuser= alumnos.get(encontrado);
    			/*La primera vez que te conectas SIMULA la validación al email*/
    			//bd.validarCuenta(currentuser.getDNI(), currentuser.getCadenaValidacion());
    			
    			if(currentuser.getCadenaValidacion()==null) {
    				ctrl.setAlumno(currentuser);
        			destino = "mainBueno.xhtml";
    			}else {
    				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Cuenta inactiva", "Cuenta inactiva"));
    			}
    			
    		}
    	}else {
    		Profesor act2 = new Profesor();
    		act2.setDNI(usuario);
        	act2.setPassword(contrasenia);
        	
            encontrado = prof.indexOf(act2);
        	if(encontrado!=-1) {
        		if(!prof.get(encontrado).getPassword().equals(contrasenia)) {
                    ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Contraseña errónea", "Contraseña errónea"));
        		}else {
        			currentuser2 = prof.get(encontrado);
        			/*La primera vez que te conectas SIMULA la validación al email*/
        			//bd.validarCuenta(currentuser2.getDNI(), currentuser2.getCadenaValidacion());
        			
        			if(currentuser2.getCadenaValidacion()==null) {
            			ctrl.setProfesor(currentuser2);
            			destino = "mainBuenoprof.xhtml";
        			}else {
        				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Cuenta inactiva", "Cuenta inactiva"));
        			}
        		}
        	}else {
                ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Usuario no existente", "Usuario no existente"));
        	}
    	}
        return destino;
    }
    
    
    
    
    public static void main (String args []) throws ParseException {
    	
		Login a= new Login();
		
		Actividades o = new Actividades();
    	o.setNombre("asd");
    	o.setDescripcion("asd");
    	o.setPlazas(Integer.parseInt("30"));
    	o.setTipo("asd");
    	o.setParticipaUsuario(new ArrayList<Usuario>());
    	o.setOng(Login.currentONG);
		
		System.out.println("LLEGO");
		
    	
    }
    
    
    
    
}