package es.uma.informatica.sii.jsf.autenticacion;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import es.uma.informatica.sii.ejb.BasedeDatosLocal;
import es.uma.informatica.sii.jsf.autenticacion.modelo.*;


/**
 *
 * @author cobrilla
 */
@Named(value = "crearValoracionActividad")
@RequestScoped
public class CrearValoracionActividad {

	private String descripcion;
    private String puntuacion;
    private Date fecha3 = new SimpleDateFormat("dd/MM/yyyy").parse("29/04/2020");
    
    @Inject
    private BasedeDatosLocal bd;
    
    @Inject
    private ControlAutorizacion ctrl;
	
    public CrearValoracionActividad() throws ParseException {
    	
    }
    
    
	public String getDescripcion() {
		return descripcion;
	}




	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}




	public String getPuntuacion() {
		return puntuacion;
	}




	public void setPuntuacion(String puntuacion) {
		this.puntuacion = puntuacion;
	}




	public String crearValoracion() {
		FacesContext ctx = FacesContext.getCurrentInstance();
		Usuario aux3 = new Usuario();
		if(ctrl.getCurrentalumno()!=null) {
			aux3=ctrl.getCurrentalumno();
		}else if(ctrl.getCurrentprofesor()!=null) {
			aux3=ctrl.getCurrentprofesor();
		}
		
		if(bd.ActividadYaValorada(Login.currentActividad,aux3)) {
			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "No puedes volver a valorar esta actividad", "No puedes volver a valorar esta actividad"));
			return "perfilActividad.xhtml";
		}else {
			if(puntuacion==null||descripcion==null) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Rellena los campos", "Rellena los campos"));
				return "crearValoracionActividad.xhtml";
			}
			
			ValoracionActividad v = new ValoracionActividad();
			v.setContenido(descripcion);
			v.setFk_actividad(Login.currentActividad);
			v.setPuntuacion(Integer.parseInt(puntuacion));
			v.setFecha(fecha3);
			
			v.setFk_user_va(aux3);
			
			
			bd.aniadirValoracionActividad(v);
		}
		
		return "perfilActividad.xhtml";
	}
    
    
  

    
    
    
    
}