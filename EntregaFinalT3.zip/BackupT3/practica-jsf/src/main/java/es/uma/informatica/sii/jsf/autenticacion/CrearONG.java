/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uma.informatica.sii.jsf.autenticacion;

import java.util.ArrayList;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.NamedQuery;

import es.uma.informatica.sii.ejb.BasedeDatosLocal;
import es.uma.informatica.sii.jsf.autenticacion.modelo.*;

/**
 *
 * @author ELcochedepeblo
 */

@Named(value = "crearONG")
@RequestScoped
public class CrearONG {

	@Inject
	private BasedeDatosLocal bd;
	
	@Inject
    private ControlAutorizacion ctrl;
	
	private String nombre=null;
	
	private String descripcion=null;
  
    
	public String getDescripcion(){
		return descripcion;
	}
    
    public String getNombre() {
		return nombre;
    }
    


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion=descripcion;
	}

	




    
    public CrearONG() {
    	
    	
    	
    }
    
    public String actualizar() {
    	ONG u = new ONG();
    	u=Login.currentONG;
    	
    	if(nombre!=null) {
    		u.setNombre(nombre);
    	}
    	
    	if(descripcion!=null) {
    		u.setDescripcion(descripcion);
    	}
    		
    	
    	bd.actualizarONG(u);
    	
    	
    	nombre=null;
    	descripcion=null;
    	
        return "perfilONGprof";
    }
    
   
    public String crear() {
    	ONG o = new ONG();
    	o.setNombre(nombre);
    	o.setDescripcion(descripcion);
    	o.setOngs_profesor(ctrl.getCurrentprofesor());
    	o.setActividades(new ArrayList<Actividades>());
    	o.setBorrada(false);
    	
    	bd.aniadirONG(o);
    	
    	nombre = null;
    	descripcion = null;
    	
    	return "mainBuenoprof.xhtml";
    	
    }
    
    
    
    
   /* public static void main (String args []) {
    	Login a = new Login();
    	Alumno act = new Alumno();
    	act.setDNI("javiA");
    	act.setApellido1("asd");
    	act.setApellido2("asd");
    	act.setPassword("bd");
    	int encontrado = Login.alumnos.indexOf(act);
    	
    	System.out.println(encontrado);
    	System.out.println(Login.alumnos.size());
    	Login.alumnos.add(act);
    	System.out.println(Login.alumnos.get(20).getPassword().equals("bd"));
    }*/
    
}
