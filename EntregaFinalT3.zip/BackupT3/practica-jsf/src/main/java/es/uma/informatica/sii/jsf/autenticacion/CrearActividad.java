/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.uma.informatica.sii.jsf.autenticacion;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import es.uma.informatica.sii.ejb.BasedeDatosLocal;
import es.uma.informatica.sii.jsf.autenticacion.modelo.*;

/**
 *
 * @author ELcochedepeblo
 */
@Named(value = "crearActividad")
@RequestScoped
public class CrearActividad {

	Actividades b = new Actividades();
	
	@Inject
	private BasedeDatosLocal bd;
	
	private String nombre;
	
	private String descripcion;
	private String Fecha_ini;
	private String Fecha_fin;
	private String plazas;
	
	private String tipo;
	
  
    
	public String getDescripcion(){
		return descripcion;
	}
    
  

	public String getFecha_ini() {
		return Fecha_ini;
	}



	public void setFecha_ini(String fecha_ini) {
		Fecha_ini = fecha_ini;
	}



	public String getFecha_fin() {
		return Fecha_fin;
	}



	public void setFecha_fin(String fecha_fin) {
		Fecha_fin = fecha_fin;
	}



	public String getPlazas() {
		return plazas;
	}

	public void setPlazas(String plazas) {
		this.plazas = plazas;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getNombre() {
		return nombre;
    }
    


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion=descripcion;
	}
    
    public CrearActividad() {
    	
    }
    
    public String editar() throws ParseException {
    	Actividades u = new Actividades();
    	u=Login.currentActividad;
    	FacesContext ctx = FacesContext.getCurrentInstance();
    	
    	if(nombre!=null) {
    		u.setNombre(nombre);
    	}
    	
    	if(descripcion!=null) {
    		u.setDescripcion(descripcion);
    	}
    		
    	if(Fecha_ini!=null) {
    		Date fecha1 = new SimpleDateFormat("dd/MM/yyyy").parse(Fecha_ini);
    		u.setFecha_Inicio(fecha1);
            
    	}
    	
    	if(Fecha_fin!=null) {
    		Date fecha2 = new SimpleDateFormat("dd/MM/yyyy").parse(Fecha_fin);
    		u.setFecha_Fin(fecha2);
    	}
    	
    	if(tipo!=null) {
    		u.setTipo(tipo);
    	}
    	
    	if(plazas!=null) {
    		if(Integer.parseInt(plazas)<u.getParticipaUsuario().size()) {
    			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Tienes mas alumnos matriculados de los que quieres poner", "Tienes mas alumnos matriculados de los que quieres poner"));
    			nombre=null;
    			descripcion=null;
    			Fecha_ini=null;
    			Fecha_fin=null;
    			plazas=null;
    			tipo=null;
    			return "perfilActividad.xhtml";
    			
    		}else {
    			u.setPlazas(Integer.parseInt(plazas));
    		}
    			
    	}
    	
    		
    	
    	bd.actualizarActividad(u);
    	
    	
    	nombre=null;
		descripcion=null;
		Fecha_ini=null;
		Fecha_fin=null;
		plazas=null;
		tipo=null;
		
		return "perfilActividad.xhtml";
    }
  
    
    
   
    public String crear() throws ParseException {
    	Date fecha1 = new SimpleDateFormat("dd/MM/yyyy").parse(Fecha_ini);
        Date fecha2 = new SimpleDateFormat("dd/MM/yyyy").parse(Fecha_fin);
    	
    	Actividades o = new Actividades();
    	o.setNombre(nombre);
    	o.setDescripcion(descripcion);
    	o.setPlazas(Integer.parseInt(plazas));
    	o.setTipo(tipo);
    	o.setParticipaUsuario(new ArrayList<Usuario>());
    	o.setOng(Login.currentONG);
    	o.setFecha_Inicio(fecha1);
    	o.setFecha_Fin(fecha2);
    	o.setListaValoraciones(new ArrayList<ValoracionActividad>());
    	o.setBorrada(false);
    	
    	bd.aniadirActividad(o);
    	
    	nombre=null;
		descripcion=null;
		Fecha_ini=null;
		Fecha_fin=null;
		plazas=null;
		tipo=null;
    	
    	return "perfilONGprof.xhtml";
    }
    
   /* public static void main (String args []) {
    	Login a = new Login();
    	Alumno act = new Alumno();
    	act.setDNI("javiA");
    	act.setApellido1("asd");
    	act.setApellido2("asd");
    	act.setPassword("bd");
    	int encontrado = Login.alumnos.indexOf(act);
    	
    	System.out.println(encontrado);
    	System.out.println(Login.alumnos.size());
    	Login.alumnos.add(act);
    	System.out.println(Login.alumnos.get(20).getPassword().equals("bd"));
    }*/
    
}
